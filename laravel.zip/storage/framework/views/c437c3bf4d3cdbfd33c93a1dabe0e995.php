<?php if(session('notification')): ?>
    <?php
        $text = session('notification')['text'];
        $title = session('notification')['title'];
        $icon = session('notification')['icon'];
    ?>
    <script>
        Swal.fire({
            icon: '<?php echo e($icon); ?>',
            title: '<?php echo e($title); ?>',
            text: '<?php echo e($text); ?>',
            showConfirmButton: true,
            confirmButtonColor: '#0f766e',
        })
    </script>
<?php endif; ?>

<?php if($errors->any()): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Gagal',
            text: '<?php echo e($errors->first()); ?>',
            showConfirmButton: true,
            confirmButtonColor: '#0f766e',
        })
    </script>
<?php endif; ?>
<?php /**PATH C:\laragon\www\tangerine\resources\views/partials/notification.blade.php ENDPATH**/ ?>