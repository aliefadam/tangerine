<?php $__env->startSection('content'); ?>
    <h1>TESSS</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\tangerine\resources\views/welcome.blade.php ENDPATH**/ ?>